# rccr
rccr is a Python library for regression clustering (finding clusters based on linear regression) and clustered regression (producing a regression from a combination of individual regressions).
Dependencies can be installed using pip or conda. An environment package is provided for convenience. Run time will vary depending on set parameters but will typically take 10-15 minutes
to reproduce the models in the main text (8 CPU). Environment installation time will vary depending on initial packages. This code has been tested on both macOS and linux operating systems. No non-standard hardware is required. 

### Usage

```python
from rccr import rccr
```

### Tests
Notebooks with data analysis for case studies presented in the main text and supporting information.
These tests also serve as examples for how to use the rccr library. These notebooks will reproduce the results from the main text. 

### Results
Raw data results for key case studies in the main text and supporting information are included here.

### Data
Data used for case studies in the main text and supporting information. 