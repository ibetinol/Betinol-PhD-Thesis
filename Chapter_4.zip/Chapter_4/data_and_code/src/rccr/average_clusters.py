import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import SpectralClustering
from sklearn.linear_model import LinearRegression
from joblib import Parallel, delayed

from .helper import cluster_fit
from .rc_fit import rc_fit


def get_average_clusters(x,y, n_clusters, iterations, max_iteration_cluster=5, plot=True, random_seed=0, num_jobs=4):
     
    """   
    Performs regression clustering multiple times and creates a similarity matrix based on the number of times 
    each entry is placed in the same cluster weighted by the R2 score. Final labels are obtained by applying 
    Spectral clustering to the similarity matrix.

    Parameters:

    x (arr): Array of training features
    y (arr): Array of responses
    n_clusters (int): Number of clusters 
    iterations (int): Number of times to repeat clustering process
    max_iteration_cluster (int): Number of iterations to perform optimization in each round of OLSclustering.
    plot = determines if similiarity matrix is plotted and shown
    random_seed (int): random seed for optimization
    num_jobs(int): number of jobs for parallelization

    Returns:
    labels: array of labels
    """



    def repeat_func(x,y,max_iter_cluster, seed):
        ols_label = rc_fit(x,y, max_iteration=max_iter_cluster, n_clusters=n_clusters, scoring='r2',normalization=10000, random_seed=seed)
        error = cluster_fit(x,y,labels=ols_label, regressor=LinearRegression(), scoring='r2')
        labels = ols_label
        return(error, labels)
     # Repeats rc_fit and provides a list of the last error and labels for each iteration.

    output = Parallel(n_jobs=num_jobs)(delayed(repeat_func)(x,y,max_iteration_cluster,i+random_seed) for i in range(0,iterations))  

    errors = []
    labels = []
    for item in output:
        errors.append(item[0])
        labels.append(item[1])

    sum = np.zeros((np.shape(labels)[1],np.shape(labels)[1]))

    for x in range(0,np.shape(labels)[0]):
        layers = []
        for i in labels[x]:
            layers.append((labels[x]==i)*errors[x]) # Creates 1 layer by determining if two entries have the same cluster label
        
        sum = np.add(sum, layers)

    normalized_similarity = np.divide(sum,np.max(sum))
    
    if plot == True:
        plt.imshow(normalized_similarity, cmap='magma')
        plt.colorbar()
        plt.xlabel('Index')
        plt.ylabel('Index')
        plt.show()

    new_labels = SpectralClustering(n_clusters=n_clusters, affinity='precomputed', random_state=25).fit_predict(normalized_similarity)

    return(new_labels)
