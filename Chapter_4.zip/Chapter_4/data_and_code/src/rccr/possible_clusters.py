import numpy as np
import random
from sklearn.feature_selection import SelectKBest, r_regression
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.linear_model import LinearRegression
from mapie.regression import MapieRegressor



def get_possible_clusters(X, y, labels, scoring):
    """   
    Obtains alternative clusters for each data point. Allows data points to be a part of 
    multiple clusters.

    Parameters:

    x (arr): Array of training features
    y (arr): Array of responses
    lables (arr): Array of labels
    scoring ('MAE','r2','PI'): Scoring function used to evaluate regression.

    Returns:
    NxN array of all possible cluster labels.
    """
    regressor = LinearRegression()  

    index = list(range(0,len(labels)))
    random.shuffle(index)     #Randomize order of optimization

    zeros = np.zeros((len(X),len(np.unique(labels))))

    for cluster in range(0,len(np.unique(labels))): 

        indexes = labels == cluster
        y_k = y[indexes]
        reduced_x = X[indexes]

        if len(reduced_x[0]) != 1: 
            transformer = SelectKBest(score_func=r_regression, k=1).fit(reduced_x, y_k)
            X_k = transformer.transform(reduced_x)
        else:
            X_k = reduced_x

        # Obtain error of current clusters

        fit_regressor = regressor.fit(X_k,y_k)
        y_pred = fit_regressor.predict(X_k)

        cluster_error = r2_score(y_k,y_pred)
        cluster_mae = mean_absolute_error(y_k,y_pred)

        try:
            mapie = MapieRegressor(estimator=regressor)
            mapie.fit(X_k,y_k)
        except:
            print('Error in PI calculation')
            pass

        # Predicts new point to see if it's within error of current model.
        for i in index:
            if len(reduced_x[0]) != 1: 
                temp_x = transformer.transform(X[i].reshape(1,-1))
            else:
                temp_x = X[i].reshape(1,-1)
            temp_y = np.hstack((y_k,y[i]))
            new_pred = fit_regressor.predict(temp_x)
            temp_y_pred = np.hstack((y_pred,new_pred))
            
            if scoring == 'r2':
                new_error = r2_score(temp_y,temp_y_pred)
                if new_error >= cluster_error:
                    zeros[i,cluster] = 1
            
            if scoring == 'MAE':
                new_error = abs(new_pred-y[i])
                if new_error <= cluster_mae:
                    zeros[i,cluster] = 1
            
            if scoring == 'PI':
                y_pred, y_pis = mapie.predict(temp_x,alpha=0.05) # Can change this for different prediction intervals
                if y[i] >= y_pis[:,0] and y[i] <= y_pis[:,1]:
                    zeros[i,cluster] = 1

    return(zeros)




