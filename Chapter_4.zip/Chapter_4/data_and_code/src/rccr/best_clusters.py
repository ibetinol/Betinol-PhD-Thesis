import matplotlib.pyplot as plt
import numpy as np
from sklearn.cluster import SpectralClustering
from sklearn.linear_model import LinearRegression
from joblib import Parallel, delayed

from .helper import cluster_fit
from .rc_fit import rc_fit

def get_best_clusters(x,y, n_clusters, iterations, max_iteration_cluster=5, random_seed=0, num_jobs=4):
        
    def repeat_func(x,y,max_iter_cluster, seed):
        ols_label = rc_fit(x,y, max_iteration=max_iter_cluster, n_clusters=n_clusters, scoring='r2',normalization=10000, random_seed=seed)
        error = cluster_fit(x,y,labels=ols_label, regressor=LinearRegression(), scoring='r2')
        labels = ols_label
        return(error, labels)
    # Repeats rc_fit and provides a list of the last error and labels for each iteration.

    output = Parallel(n_jobs=num_jobs)(delayed(repeat_func)(x,y,max_iteration_cluster,i+random_seed) for i in range(0,iterations))  

    errors = []
    labels = []
    for item in output:
        errors.append(item[0])
        labels.append(item[1])
    
    best_index = np.argmax(errors)
    final_labels = labels[best_index]

    return(final_labels)