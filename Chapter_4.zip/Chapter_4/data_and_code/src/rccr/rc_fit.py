import math
import warnings
from copy import deepcopy

import numpy as np
from k_means_constrained import KMeansConstrained
from sklearn.exceptions import UndefinedMetricWarning
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, Ridge

from .helper import cluster_fit, optimize

warnings.filterwarnings('ignore', category=UndefinedMetricWarning) 


def rc_fit(X, y, max_iteration=3, n_clusters=2, initialization='KMeans', normalization=10000, scoring='r2', regressor='linear', random_seed=0):
    """
    Get clusters using regression clustering.
    Parameters:
        X (np.ndarray): X values for training
        y (np.ndarray): y values for training
        max_iterations (int): maximum iterations before stopping
        n_clusters (int): Number of clusters to create
        initialization (str): 'KMeans' or 'random' initialization
        normalization (int): Randomness factor to optimization. Higher values are less random. Default = 10000
        scoring (str): 'MSE' or 'r2'. Scoring function for regression.
        random_seed (int): random seed for optimization
    """
    if regressor == 'linear':
        regressor = LinearRegression()
    elif regressor == 'lasso':
        regressor = Lasso()
    elif regressor == 'ridge':
        regressor == Ridge()
    elif regressor == 'elasticnet':
        regressor = ElasticNet()

    np.random.seed(random_seed)

    if initialization == 'random':
        initial_labels = np.random.randint(0,high=n_clusters,size=len(y))

    else:
        initial_labels = KMeansConstrained(n_clusters = n_clusters,size_min=2,init="k-means++", random_state=0).fit_predict(X)

    initial_error = cluster_fit(X,y,initial_labels, regressor=regressor, scoring=scoring)
    print("Initial " + str(scoring) + " " + str(initial_error))

    labels = initial_labels
    iteration = 0

    while iteration < max_iteration-1:

        labels = optimize(initial_labels,labels,X,y, normalization, regressor=regressor, scoring=scoring, random_seed=random_seed)
        error = cluster_fit(X,y,labels, regressor=regressor, scoring=scoring)

        while math.isnan(error) == True:

            labels = optimize(initial_labels,labels,X,y, normalization, regressor=regressor, scoring=scoring, random_seed=random_seed)
            error = cluster_fit(X,y,labels, regressor=regressor, scoring=scoring)

        print("Iteration " + str(iteration) + " " + str(error))
        iteration +=1

    temp_labels = deepcopy(labels)

    if max_iteration != 0: # If statement in case users want to vizualize with no iterations, one last iteration with no normalization to ensure local minima reached
        no_norm_labels = optimize(initial_labels,labels,X,y,normalization='off', regressor=regressor, scoring=scoring, random_seed=random_seed)
        error = cluster_fit(X,y,no_norm_labels, regressor=regressor, scoring=scoring)
            
        if math.isnan(error) == True:
            final_labels = temp_labels
            error = cluster_fit(X,y,final_labels, regressor=regressor, scoring=scoring)
        else: 
            final_labels = no_norm_labels
            error = cluster_fit(X,y,final_labels, regressor=regressor, scoring=scoring)

        print("Final " + str(scoring) + " " + str(error))
    elif max_iteration == 0:
        final_labels = labels

    return (final_labels)

                                                                

