import random
import warnings
import numpy as np
from sklearn.feature_selection import SelectKBest, r_regression
from sklearn.metrics import r2_score

import numpy as np
from sklearn.feature_selection import SelectKBest, r_regression
from sklearn.metrics import mean_squared_error, r2_score

warnings.filterwarnings('ignore', category=RuntimeWarning) 

def cluster_fit(X,y,labels, regressor, scoring, max_features=1):
    """   
    Performs individual regressions for each cluster label by finding the best correlated n features.

    Parameters:

    x (arr): Array of training features
    y (arr): Array of responses
    lables (arr): Array of labels
    regressor (class): Untrained regressor to perform regression.
    scoring ('MSE' or 'r2'): Scoring function used to evaluate regression.
    max_features (int, Default = 1) : Maximum features to use in regression 

    Returns:
    average_error: average of the obtained errors across clusters.
    """
    
    epsilon = []


    for k in np.unique(labels):

        indexes = np.where(labels==k)
        y_k = y[indexes]

        if len(X[0]) != 1: 
            X_k = SelectKBest(score_func=r_regression, k=max_features).fit_transform(X[indexes], y_k)
        else:
            X_k = X[indexes] # If only one feature given then keep that feature


        fit_regressor = regressor.fit(X_k,y_k)
        y_pred = fit_regressor.predict(X_k)

        if scoring == 'MSE':
            epsilon.append(mean_squared_error(y_k,y_pred))
        if scoring == 'r2':
            epsilon.append(r2_score(y_k,y_pred))

    average_error = np.average(epsilon)
    
    return(average_error)

def optimize(initial_labels, labels, X, y, normalization, regressor, scoring, random_seed=0):
            """
            Changes labels to minimize/maximize scoring function.

            initial_labels (array): starting labels.
            labels (array): first iteration labels
            X (arr): Array of training features
            y (arr): Array of responses
            normalization (int): normalization setting. 
            regressor (class): Untrained regressor to perform regression.
            scoring ('MSE' or 'r2'): Scoring function used to evaluate regression.
            """
            np.random.seed(random_seed)
            indexes = list(range(0,len(initial_labels)))
            np.random.shuffle(indexes)     #Randomize order of optimization

            for i in indexes:
                new_error = []

                if isinstance(normalization, int) == True: 
                    random_rate = np.random.randint(0,normalization)
                else:
                    random_rate = 1  

                if normalization == normalization and random_rate == 0:
                        labels[i] = np.random.choice(np.unique(initial_labels)) # Assigns random label if normalization lottery hits
                else:
                    for cluster in range(0,len(np.unique(initial_labels))):
                        labels[i] = cluster
                        new_error.append(cluster_fit(X,y,labels,regressor,scoring=scoring))

                    if len(np.where(new_error == np.min(new_error))[0]) == 1:
                        if scoring == 'MSE':
                            labels[i] = np.argmin(new_error)  
                        if scoring == 'r2':
                            labels[i] = np.argmax(new_error)          
                    elif len(np.where(new_error == np.min(new_error))[0]) >1:

                        labels[i] = np.random.choice(np.where(new_error == np.min(new_error))[0])  ## Randomize if multiple minima

              
            return(labels)



