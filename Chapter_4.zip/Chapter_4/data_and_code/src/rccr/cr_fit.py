
import numpy as np
from sklearn.feature_selection import SelectKBest, r_regression
from sklearn.metrics import r2_score
from sklearn.mixture import GaussianMixture
from sklearn.linear_model import LinearRegression
import warnings


def cr_fit(X, y, labels='gmm', regressor = 'linear', max_features=1, n_clusters=2):
    
    """   
    Performs clustered regression.

    Parameters:

    x (arr): Array of training features
    y (arr): Array of responses
    labels (str or arr): 'gmm' for automatic labels using gaussian mixture or an array of determined labels
    regressor (str): Default 'linear'.
    max_features (int): maximum features to use in regression
    n_clusters (int): if labels=='gmm', how many clusters to use.

    Returns:
    measured values, predicted values, labels
    """

    training_data = []
    training_meas = []
    clusters = []

    with warnings.catch_warnings():
        warnings.simplefilter(action='ignore',category=FutureWarning) # Suppresses warnings from attempting to compare string to numpy array in cases where labels does not equal 'gmm'. 
                                                                    # This behaviour may change with future versions of python and numpy. 
        if labels == 'gmm':
            clusterer = GaussianMixture(n_components=n_clusters).fit(X)
            cluster_label = clusterer.predict(X)
        else:
            cluster_label = labels

    if regressor == 'linear':
        regressor = LinearRegression()

    for k in np.unique(cluster_label): # Cycle through available clusters

        # Define temporary X and y of only the cluster labels, reduce features, train and predict model

        indexes = np.where(cluster_label==k)
        X_k = X[indexes]
        y_k = y[indexes]

        selector = SelectKBest(score_func=r_regression, k=max_features).fit(X_k, y_k)
        X_k_red = selector.transform(X_k)

        train = regressor.fit(X_k_red,y_k)
        predict = train.predict(X_k_red)


        clusters.append(np.ones((predict.shape[0], 1)) * k) # gets array of n labels of the current cluster
        training_data.append(predict)
        training_meas.append(y_k)
        print("Cluster " + str(k) + " R2 " + str(r2_score(y_k,predict)) + " coeff " + str(train.coef_.tolist()) + str(selector.get_support(indices=True)) + " int " + str(train.intercept_))

    concat_meas = np.concatenate(training_meas, axis=0)
    concat_pred = np.concatenate(training_data, axis=0)
    concat_labels = np.concatenate(clusters, axis=0)
        
    return(concat_meas, concat_pred, concat_labels)