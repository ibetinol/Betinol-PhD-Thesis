
import numpy as np
from sklearn.feature_selection import SelectKBest, r_regression
from sklearn.metrics import r2_score
from sklearn.linear_model import LinearRegression


def cr_fit_predict(X_train, y_train, train_labels, X_test, y_test, test_labels, regressor = 'linear', max_features=1):
    """   
    Performs clustered regression then predicts new test data. 

    Parameters:

    x (arr): Array of training features
    y (arr): Array of responses
    train_labels (arr): array of labels
    x_test (arr): Array of test features
    y_test (arr): Array of test responses
    test_labels (arr): array of test labels

    regressor (str): Default 'linear'.
    max_features (int): maximum features to use in regression

    Returns:
    measured values, predicted values, labels, test measured values, test predicted values, test labels
    """

    training_data = []
    training_meas = []
    clusters = []

    test_data = []
    test_meas = []
    test_clusters = []

    if regressor == 'linear':
        regressor = LinearRegression()

    for k in np.unique(train_labels): # Cycle through available clusters

        # Define temporary X and y of only the cluster labels, reduce features, train and predict model

        indexes = np.where(train_labels==k)
        X_k = X_train[indexes]
        y_k = y_train[indexes]

        test_indexes = np.where(test_labels==k)
        X_test_k = X_test[test_indexes]
        y_test_k = y_test[test_indexes]

        selector = SelectKBest(score_func=r_regression, k=max_features).fit(X_k, y_k)
        X_k_red = selector.transform(X_k)

        if len(X_test_k) > 1:
            X_k_test_red = selector.transform(X_test_k)
        elif len(X_test_k) == 1:
            X_k_test_red = selector.transform(X_test_k.reshape(1,-1))


        train = regressor.fit(X_k_red,y_k)
        predict = train.predict(X_k_red)

        clusters.append(np.ones((predict.shape[0], 1)) * k) # gets array of n labels of the current cluster
        training_data.append(predict)
        training_meas.append(y_k)

        if len(X_test_k) >= 1:

            test_predict = train.predict(X_k_test_red)
            test_clusters.append(np.ones((test_predict.shape[0], 1)) * k) 
            test_data.append(test_predict)
            test_meas.append(y_test_k)

        print("Cluster " + str(k) + " R2 " + str(r2_score(y_k,predict)) + " coeff " + str(train.coef_.tolist()) + str(selector.get_support(indices=True)) + " int " + str(train.intercept_))

    concat_meas = np.concatenate(training_meas, axis=0)
    concat_pred = np.concatenate(training_data, axis=0)
    concat_labels = np.concatenate(clusters, axis=0)

    concat_test_meas = np.concatenate(test_meas, axis=0)
    concat_test_pred = np.concatenate(test_data, axis=0)
    concat_test_labels = np.concatenate(test_clusters, axis=0)
        
    return(concat_meas, concat_pred, concat_labels, concat_test_meas, concat_test_pred, concat_test_labels)