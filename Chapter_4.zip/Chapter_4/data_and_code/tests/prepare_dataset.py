import pandas as pd

def prepare_dataset(path):

    original_df = pd.read_excel(path, sheet_name='df')
    enolates = pd.read_excel(path, sheet_name='Enolate').set_index('Enolate').to_dict(orient='index')
    ligands = pd.read_excel(path, sheet_name='Ligands').set_index('Ligand').to_dict(orient='index')
    solvents = pd.read_excel(path, sheet_name='Solvents').set_index('Solvent').to_dict(orient='index')
    alkyls = pd.read_excel(path, sheet_name='Alkyl').set_index('Alkyl').to_dict(orient='index')

    enolate_descriptors = []
    ligand_descriptors = []
    solvent_descriptors = []
    alkyl_descriptors = []

    for enolate in original_df['enolate']:
        enolate_descriptors.append(enolates[enolate])

    for ligand in original_df['ligand']:
        ligand_descriptors.append(ligands[ligand])

    for solvent in original_df['solvent']:
        solvent_descriptors.append(solvents[solvent])

    for alkyl in original_df['alkyl']:
        alkyl_descriptors.append(alkyls[alkyl])

    descriptors = pd.DataFrame.from_dict(enolate_descriptors).join(pd.DataFrame.from_dict(ligand_descriptors)).join(pd.DataFrame.from_dict(alkyl_descriptors)).join(pd.DataFrame.from_dict(solvent_descriptors))
    new_df = original_df.join(descriptors)

    return(new_df)