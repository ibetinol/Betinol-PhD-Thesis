"""
Created on Nov 19 2024
"""

import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors.MoleculeDescriptors import MolecularDescriptorCalculator
from sklearn.cluster import KMeans
import warnings

def k_cluster(data,num_clusters, random_state=25):
    """
    Obtain cluster labels for num_clusters with standard hyperparameters

    Parameter
    data: input data for clustering
    num_clusters: # of clusters
    """
    kmeans = KMeans(
        init="k-means++",
        n_clusters=num_clusters,
        n_init=10,
        max_iter=300,
        random_state=random_state
    )
    
    fit = kmeans.fit(data)
    labels = fit.labels_

    return(labels)

def get_clusters(data,max_cluster):
    """
    Obtain inertia values for a range of clusters

    Parameter
    data: input data for clustering
    max_cluster: highest cluster value to look for 
    """
    range_ = range(2,max_cluster)
    inertia = []
    for i in range_:
        kmeans = KMeans(
            init="k-means++",
            n_clusters=i,
            n_init=10,
            max_iter=300,
            random_state=25
        )
        cluster = kmeans.fit(data)
        inertia.append(cluster.inertia_)

    return(range_, inertia)

def calc_generality(df, group, group_col, resp, cluster_labels, cutoff):
    """
    Calculate generality scores (Proportion of clusters deemed succesful)
    for a group. Target values and groups must be in a pandas dataframe.

    Parameter
    df: DataFrame
    group: grouping (i.e. specific catalyst, catalyst class)
    group_col: Column name of groups
    resp: response column name (ee, yield, etc.)
    cluster: clustering labels
    cutoff: Value for success
    """
    with warnings.catch_warnings():
        warnings.simplefilter('error')

        try:
            cluster = pd.DataFrame({'Cluster':cluster_labels})
            df = df.join(cluster).reset_index(drop=True)
            new_df = df[df[group_col] == group].reset_index(drop=True)
            num_clusters = len(cluster['Cluster'].unique())
            cluster_ = new_df['Cluster'].unique()

            cluster_ee = []
            cluster_number = []

            for cluster_val in cluster_:
                cluster_df = new_df[new_df['Cluster'] == cluster_val]
                avg_ee = np.average(cluster_df[resp])
                cluster_ee.append(avg_ee)
                cluster_number.append(cluster_val)

            cluster_ee_df = pd.DataFrame({'ee':cluster_ee})
            generality = np.sum(cluster_ee_df.ee >= cutoff)/num_clusters
        except:
            warnings.warn(f"Error in calculating generality for {group} at cluster {cluster_val}.")


    return(generality, cluster_number, cluster_ee)

def average_ee(cat_class, class_col, df, ee_name='ee'):
    """
    Determine average ee
    Parameter
    cat_class:  class under study
    class_col: column header of classes
    df: dataframe with data
    """

    new_df = df[df[class_col] == cat_class]
    avg_ee = np.average(new_df[ee_name])

    return avg_ee

def ddg2ee(ddg, temp):
    """
    Convert ddg to ee

    Parameter
    ddg: Delta delta G value
    temp: temperature
    """
    er = np.exp(-ddg/(0.001986*temp)) 
    ee = (100*(1-er))/(1+er)

    return ee
