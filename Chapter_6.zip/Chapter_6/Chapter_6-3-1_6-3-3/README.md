# A Data-Driven Workflow for Assigning and Predicting Generality in Asymmetric Catalysis 

Contained is the code and data used for the paper "A Data-Driven Workflow for Assigning and Predicting Generality in Asymmetric Catalysis"

## Data 

The data folder contains the the databases for both case studies. The raw folder contains the unprocessed databases for the organocatalytic Mannich reaction and the CPA catalyzed addition to imines training reactions. The interim folder contains alternative representations of the Mannich database. For example, lists of all unique reactions or catalysts can be found here. The processed folder contains the final spreadsheets used for modelling. This includes reaction descriptors for both the Mannich and CPA datasets, as well as different cut offs for the Mannich database. All files will have the prefix "mannich" or "CPA" to denote which case study the data is for.

## Notebooks

The notebooks folder is organized as a set of experiments with each notebook showing 1 result. Each notebook will have the prefix "mannich" or "CPA" to denote the case study the code is used for. An environment file is included here as well. 

### Functions 

Common functions used for this project are included in the "common_functions.py" script including "calc_generality", the function that will take a list of cluster labels, ee, and catalyst type and output generality scores.